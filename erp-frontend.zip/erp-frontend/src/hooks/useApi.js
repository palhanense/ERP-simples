import { useState, useEffect } from 'react'

const API_BASE_URL = 'https://nghki1cjq3wq.manus.space/api'

export const useApi = () => {
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState(null)

  const request = async (endpoint, options = {}) => {
    setLoading(true)
    setError(null)
    
    try {
      const response = await fetch(`${API_BASE_URL}${endpoint}`, {
        headers: {
          'Content-Type': 'application/json',
          ...options.headers,
        },
        ...options,
      })
      
      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`)
      }
      
      const data = await response.json()
      setLoading(false)
      return data
    } catch (err) {
      setError(err.message)
      setLoading(false)
      throw err
    }
  }

  return { request, loading, error }
}

export const useProdutos = () => {
  const [produtos, setProdutos] = useState([])
  const { request, loading, error } = useApi()

  const listarProdutos = async () => {
    try {
      const data = await request('/produtos')
      setProdutos(data)
      return data
    } catch (err) {
      console.error('Erro ao listar produtos:', err)
      return []
    }
  }

  const criarProduto = async (produto) => {
    try {
      const data = await request('/produtos', {
        method: 'POST',
        body: JSON.stringify(produto),
      })
      await listarProdutos() // Recarrega a lista
      return data
    } catch (err) {
      console.error('Erro ao criar produto:', err)
      throw err
    }
  }

  const atualizarProduto = async (id, produto) => {
    try {
      const data = await request(`/produtos/${id}`, {
        method: 'PUT',
        body: JSON.stringify(produto),
      })
      await listarProdutos() // Recarrega a lista
      return data
    } catch (err) {
      console.error('Erro ao atualizar produto:', err)
      throw err
    }
  }

  const deletarProduto = async (id) => {
    try {
      await request(`/produtos/${id}`, {
        method: 'DELETE',
      })
      await listarProdutos() // Recarrega a lista
    } catch (err) {
      console.error('Erro ao deletar produto:', err)
      throw err
    }
  }

  const produtosBaixoEstoque = async () => {
    try {
      const data = await request('/produtos/baixo-estoque')
      return data
    } catch (err) {
      console.error('Erro ao buscar produtos com baixo estoque:', err)
      return []
    }
  }

  useEffect(() => {
    listarProdutos()
  }, [])

  return {
    produtos,
    loading,
    error,
    listarProdutos,
    criarProduto,
    atualizarProduto,
    deletarProduto,
    produtosBaixoEstoque,
  }
}

export const useClientes = () => {
  const [clientes, setClientes] = useState([])
  const { request, loading, error } = useApi()

  const listarClientes = async () => {
    try {
      const data = await request('/clientes')
      setClientes(data)
      return data
    } catch (err) {
      console.error('Erro ao listar clientes:', err)
      return []
    }
  }

  const criarCliente = async (cliente) => {
    try {
      const data = await request('/clientes', {
        method: 'POST',
        body: JSON.stringify(cliente),
      })
      await listarClientes() // Recarrega a lista
      return data
    } catch (err) {
      console.error('Erro ao criar cliente:', err)
      throw err
    }
  }

  const atualizarCliente = async (id, cliente) => {
    try {
      const data = await request(`/clientes/${id}`, {
        method: 'PUT',
        body: JSON.stringify(cliente),
      })
      await listarClientes() // Recarrega a lista
      return data
    } catch (err) {
      console.error('Erro ao atualizar cliente:', err)
      throw err
    }
  }

  const deletarCliente = async (id) => {
    try {
      await request(`/clientes/${id}`, {
        method: 'DELETE',
      })
      await listarClientes() // Recarrega a lista
    } catch (err) {
      console.error('Erro ao deletar cliente:', err)
      throw err
    }
  }

  const buscarClientes = async (termo) => {
    try {
      const data = await request(`/clientes/buscar?q=${encodeURIComponent(termo)}`)
      return data
    } catch (err) {
      console.error('Erro ao buscar clientes:', err)
      return []
    }
  }

  useEffect(() => {
    listarClientes()
  }, [])

  return {
    clientes,
    loading,
    error,
    listarClientes,
    criarCliente,
    atualizarCliente,
    deletarCliente,
    buscarClientes,
  }
}

export const useVendas = () => {
  const [vendas, setVendas] = useState([])
  const { request, loading, error } = useApi()

  const listarVendas = async (page = 1, perPage = 20) => {
    try {
      const data = await request(`/vendas?page=${page}&per_page=${perPage}`)
      setVendas(data.vendas || [])
      return data
    } catch (err) {
      console.error('Erro ao listar vendas:', err)
      return { vendas: [], total: 0, pages: 0, current_page: 1 }
    }
  }

  const criarVenda = async (venda) => {
    try {
      const data = await request('/vendas', {
        method: 'POST',
        body: JSON.stringify(venda),
      })
      await listarVendas() // Recarrega a lista
      return data
    } catch (err) {
      console.error('Erro ao criar venda:', err)
      throw err
    }
  }

  const atualizarVenda = async (id, venda) => {
    try {
      const data = await request(`/vendas/${id}`, {
        method: 'PUT',
        body: JSON.stringify(venda),
      })
      await listarVendas() // Recarrega a lista
      return data
    } catch (err) {
      console.error('Erro ao atualizar venda:', err)
      throw err
    }
  }

  const cancelarVenda = async (id) => {
    try {
      await request(`/vendas/${id}/cancelar`, {
        method: 'POST',
      })
      await listarVendas() // Recarrega a lista
    } catch (err) {
      console.error('Erro ao cancelar venda:', err)
      throw err
    }
  }

  const dashboardVendas = async () => {
    try {
      const data = await request('/vendas/dashboard')
      return data
    } catch (err) {
      console.error('Erro ao buscar dados do dashboard:', err)
      return { vendas_mes: 0, num_vendas_mes: 0, vendas_recentes: [] }
    }
  }

  useEffect(() => {
    listarVendas()
  }, [])

  return {
    vendas,
    loading,
    error,
    listarVendas,
    criarVenda,
    atualizarVenda,
    cancelarVenda,
    dashboardVendas,
  }
}

