import { useState, useEffect } from 'react'
import { Button } from '@/components/ui/button.jsx'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card.jsx'
import { Badge } from '@/components/ui/badge.jsx'
import { Input } from '@/components/ui/input.jsx'
import { Label } from '@/components/ui/label.jsx'
import { Textarea } from '@/components/ui/textarea.jsx'
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog.jsx'
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table.jsx'
import {
  Plus,
  Edit,
  Trash2,
  ShoppingCart,
  DollarSign,
  Calendar,
  User,
  Package,
  XCircle,
  CheckCircle,
  Search
} from 'lucide-react'
import { useVendas, useProdutos, useClientes } from '../hooks/useApi'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select.jsx'

export default function VendasTab() {
  const { vendas, loading, error, listarVendas, criarVenda, cancelarVenda } = useVendas()
  const { produtos, listarProdutos } = useProdutos()
  const { clientes, listarClientes } = useClientes()

  const [dialogOpen, setDialogOpen] = useState(false)
  const [newSaleData, setNewSaleData] = useState({
    cliente_id: '',
    itens: [],
    status: 'pendente',
    observacoes: ''
  })
  const [selectedProduct, setSelectedProduct] = useState(null)
  const [productQuantity, setProductQuantity] = useState(1)
  const [searchTerm, setSearchTerm] = useState('')

  useEffect(() => {
    listarVendas()
    listarProdutos()
    listarClientes()
  }, [])

  const handleAddProduct = () => {
    if (selectedProduct && productQuantity > 0) {
      const existingItemIndex = newSaleData.itens.findIndex(item => item.produto_id === selectedProduct.id)

      if (existingItemIndex > -1) {
        const updatedItens = [...newSaleData.itens]
        updatedItens[existingItemIndex].quantidade += productQuantity
        setNewSaleData({ ...newSaleData, itens: updatedItens })
      } else {
        setNewSaleData({
          ...newSaleData,
          itens: [
            ...newSaleData.itens,
            {
              produto_id: selectedProduct.id,
              nome_produto: selectedProduct.nome,
              quantidade: productQuantity,
              preco_unitario: selectedProduct.preco
            }
          ]
        })
      }
      setSelectedProduct(null)
      setProductQuantity(1)
    }
  }

  const handleRemoveProduct = (index) => {
    const updatedItens = newSaleData.itens.filter((_, i) => i !== index)
    setNewSaleData({ ...newSaleData, itens: updatedItens })
  }

  const calculateTotal = () => {
    return newSaleData.itens.reduce((sum, item) => sum + (item.quantidade * item.preco_unitario), 0)
  }

  const handleSubmit = async (e) => {
    e.preventDefault()
    try {
      const vendaData = {
        cliente_id: newSaleData.cliente_id ? parseInt(newSaleData.cliente_id) : null,
        itens: newSaleData.itens.map(item => ({
          produto_id: item.produto_id,
          quantidade: item.quantidade
        })),
        observacoes: newSaleData.observacoes
      }
      await criarVenda(vendaData)
      setDialogOpen(false)
      resetForm()
    } catch (err) {
      console.error('Erro ao criar venda:', err)
    }
  }

  const handleCancelSale = async (id) => {
    if (confirm('Tem certeza que deseja cancelar esta venda?')) {
      try {
        await cancelarVenda(id)
      } catch (err) {
        console.error('Erro ao cancelar venda:', err)
      }
    }
  }

  const resetForm = () => {
    setNewSaleData({
      cliente_id: '',
      itens: [],
      status: 'pendente',
      observacoes: ''
    })
    setSelectedProduct(null)
    setProductQuantity(1)
  }

  const handleDialogClose = () => {
    setDialogOpen(false)
    resetForm()
  }

  const getStatusBadge = (status) => {
    switch (status) {
      case 'concluida':
        return <Badge variant="default" className="bg-green-500">Concluída</Badge>
      case 'cancelada':
        return <Badge variant="destructive">Cancelada</Badge>
      case 'pendente':
      default:
        return <Badge variant="secondary">Pendente</Badge>
    }
  }

  const vendasFiltradas = vendas.filter(venda =>
    venda.cliente_nome?.toLowerCase().includes(searchTerm.toLowerCase()) ||
    venda.id.toString().includes(searchTerm)
  )

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-3xl font-bold tracking-tight">Vendas</h2>
        <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
          <DialogTrigger asChild>
            <Button onClick={() => setDialogOpen(true)}>
              <Plus className="h-4 w-4 mr-2" />
              Nova Venda
            </Button>
          </DialogTrigger>
          <DialogContent className="sm:max-w-[600px] max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>Nova Venda</DialogTitle>
              <DialogDescription>
                Registre uma nova venda no sistema.
              </DialogDescription>
            </DialogHeader>
            <form onSubmit={handleSubmit}>
              <div className="grid gap-4 py-4">
                <div className="grid grid-cols-4 items-center gap-4">
                  <Label htmlFor="cliente" className="text-right">Cliente</Label>
                  <Select
                    onValueChange={(value) => setNewSaleData({ ...newSaleData, cliente_id: value })}
                    value={newSaleData.cliente_id}
                  >
                    <SelectTrigger className="col-span-3">
                      <SelectValue placeholder="Selecione um cliente (opcional)" />
                    </SelectTrigger>
                    <SelectContent>
                      {clientes.map(cliente => (
                        <SelectItem key={cliente.id} value={cliente.id.toString()}>
                          {cliente.nome}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="grid grid-cols-4 items-center gap-4">
                  <Label htmlFor="produto" className="text-right">Adicionar Produto</Label>
                  <Select
                    onValueChange={(value) => setSelectedProduct(produtos.find(p => p.id.toString() === value))}
                    value={selectedProduct ? selectedProduct.id.toString() : ''}
                  >
                    <SelectTrigger className="col-span-2">
                      <SelectValue placeholder="Selecione um produto" />
                    </SelectTrigger>
                    <SelectContent>
                      {produtos.map(produto => (
                        <SelectItem key={produto.id} value={produto.id.toString()}>
                          {produto.nome} (Estoque: {produto.estoque_atual})
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <Input
                    type="number"
                    value={productQuantity}
                    onChange={(e) => setProductQuantity(parseInt(e.target.value))}
                    min="1"
                    className="col-span-1"
                  />
                </div>
                <div className="col-span-4 flex justify-end">
                  <Button type="button" onClick={handleAddProduct} disabled={!selectedProduct || productQuantity <= 0}>
                    Adicionar Item
                  </Button>
                </div>

                {newSaleData.itens.length > 0 && (
                  <div className="col-span-4">
                    <h4 className="text-lg font-semibold mb-2">Itens da Venda</h4>
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>Produto</TableHead>
                          <TableHead>Qtd</TableHead>
                          <TableHead>Preço Unit.</TableHead>
                          <TableHead>Total</TableHead>
                          <TableHead className="text-right">Ações</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {newSaleData.itens.map((item, index) => (
                          <TableRow key={index}>
                            <TableCell>{item.nome_produto}</TableCell>
                            <TableCell>{item.quantidade}</TableCell>
                            <TableCell>R$ {item.preco_unitario.toFixed(2)}</TableCell>
                            <TableCell>R$ {(item.quantidade * item.preco_unitario).toFixed(2)}</TableCell>
                            <TableCell className="text-right">
                              <Button
                                variant="destructive"
                                size="sm"
                                onClick={() => handleRemoveProduct(index)}
                              >
                                <Trash2 className="h-4 w-4" />
                              </Button>
                            </TableCell>
                          </TableRow>
                        ))}
                        <TableRow>
                          <TableCell colSpan="3" className="text-right font-bold">Total da Venda:</TableCell>
                          <TableCell className="font-bold">R$ {calculateTotal().toFixed(2)}</TableCell>
                          <TableCell></TableCell>
                        </TableRow>
                      </TableBody>
                    </Table>
                  </div>
                )}

                <div className="grid grid-cols-4 items-center gap-4">
                  <Label htmlFor="observacoes" className="text-right">Observações</Label>
                  <Textarea
                    id="observacoes"
                    value={newSaleData.observacoes}
                    onChange={(e) => setNewSaleData({ ...newSaleData, observacoes: e.target.value })}
                    className="col-span-3"
                    rows={3}
                  />
                </div>
              </div>
              <DialogFooter>
                <Button type="button" variant="outline" onClick={handleDialogClose}>
                  Cancelar
                </Button>
                <Button type="submit" disabled={newSaleData.itens.length === 0}>
                  Registrar Venda
                </Button>
              </DialogFooter>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      {/* Lista de Vendas */}
      <Card>
        <CardHeader>
          <CardTitle>Histórico de Vendas</CardTitle>
          <CardDescription>
            Visualize e gerencie todas as vendas realizadas.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex items-center space-x-2 mb-4">
            <Search className="h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Buscar vendas por cliente ou ID..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="max-w-sm"
            />
          </div>

          {loading ? (
            <div className="text-center py-4">Carregando vendas...</div>
          ) : error ? (
            <div className="text-center py-4 text-red-500">Erro: {error}</div>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>ID Venda</TableHead>
                  <TableHead>Cliente</TableHead>
                  <TableHead>Data</TableHead>
                  <TableHead>Total</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead className="text-right">Ações</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {vendasFiltradas.map((venda) => (
                  <TableRow key={venda.id}>
                    <TableCell className="font-medium">#{venda.id}</TableCell>
                    <TableCell>
                      <div className="flex items-center gap-2">
                        <User className="h-4 w-4" />
                        {venda.cliente_nome || 'Cliente Não Informado'}
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center gap-2">
                        <Calendar className="h-4 w-4" />
                        {new Date(venda.data_criacao).toLocaleDateString('pt-BR')}
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center gap-2">
                        <DollarSign className="h-4 w-4" />
                        R$ {venda.total_venda.toFixed(2)}
                      </div>
                    </TableCell>
                    <TableCell>
                      {getStatusBadge(venda.status)}
                    </TableCell>
                    <TableCell className="text-right">
                      <div className="flex justify-end gap-2">
                        {venda.status === 'pendente' && (
                          <Button
                            variant="destructive"
                            size="sm"
                            onClick={() => handleCancelSale(venda.id)}
                          >
                            <XCircle className="h-4 w-4" />
                          </Button>
                        )}
                        {/* <Button
                          variant="outline"
                          size="sm"
                          onClick={() => handleEdit(venda)}
                        >
                          <Edit className="h-4 w-4" />
                        </Button> */}
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}

          {vendasFiltradas.length === 0 && !loading && (
            <div className="text-center py-8 text-muted-foreground">
              {searchTerm ? 'Nenhuma venda encontrada para a busca.' : 'Nenhuma venda registrada ainda.'}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  )
}

