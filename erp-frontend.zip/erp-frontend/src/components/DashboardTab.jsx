import { useState, useEffect } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card.jsx'
import { Badge } from '@/components/ui/badge.jsx'
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer,
  LineChart,
  Line,
  PieChart,
  Pie,
  Cell,
  Area,
  AreaChart
} from 'recharts'
import { 
  TrendingUp, 
  TrendingDown, 
  DollarSign, 
  Package, 
  Users, 
  ShoppingCart,
  AlertTriangle,
  Calendar,
  Target,
  Activity
} from 'lucide-react'

export default function DashboardTab() {
  const [dashboardData, setDashboardData] = useState({
    resumo: {
      vendas_mes: 0,
      total_produtos: 0,
      total_clientes: 0,
      produtos_baixo_estoque: 0,
      vendas_hoje: 0,
      receita_mes: 0
    },
    vendas_por_dia: [],
    produtos_mais_vendidos: [],
    vendas_por_categoria: [],
    vendas_recentes: [],
    estoque_critico: []
  })
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(null)

  useEffect(() => {
    fetchDashboardData()
  }, [])

  const fetchDashboardData = async () => {
    try {
      setLoading(true)
      
      // Buscar dados de diferentes endpoints
      const [
        produtosRes,
        clientesRes,
        vendasRes,
        baixoEstoqueRes
      ] = await Promise.all([
        fetch('http://localhost:5000/api/produtos'),
        fetch('http://localhost:5000/api/clientes'),
        fetch('http://localhost:5000/api/vendas?page=1&per_page=100'),
        fetch('http://localhost:5000/api/produtos/baixo-estoque')
      ])

      const produtos = await produtosRes.json()
      const clientes = await clientesRes.json()
      const vendasData = await vendasRes.json()
      const baixoEstoque = await baixoEstoqueRes.json()

      const vendas = vendasData.vendas || []

      // Calcular métricas
      const hoje = new Date().toISOString().split('T')[0]
      const inicioMes = new Date(new Date().getFullYear(), new Date().getMonth(), 1).toISOString().split('T')[0]
      
      const vendasMes = vendas.filter(v => v.data_venda >= inicioMes)
      const vendasHoje = vendas.filter(v => v.data_venda.startsWith(hoje))
      
      const receitaMes = vendasMes.reduce((sum, v) => sum + parseFloat(v.total), 0)
      
      // Vendas por dia (últimos 7 dias)
      const vendasPorDia = []
      for (let i = 6; i >= 0; i--) {
        const data = new Date()
        data.setDate(data.getDate() - i)
        const dataStr = data.toISOString().split('T')[0]
        const vendasDia = vendas.filter(v => v.data_venda.startsWith(dataStr))
        const receita = vendasDia.reduce((sum, v) => sum + parseFloat(v.total), 0)
        
        vendasPorDia.push({
          data: data.toLocaleDateString('pt-BR', { day: '2-digit', month: '2-digit' }),
          vendas: vendasDia.length,
          receita: receita
        })
      }

      // Produtos mais vendidos (simulado - seria calculado dos itens de venda)
      const produtosMaisVendidos = produtos.slice(0, 5).map((produto, index) => ({
        nome: produto.nome,
        vendas: Math.floor(Math.random() * 50) + 10,
        receita: (Math.floor(Math.random() * 50) + 10) * produto.preco
      })).sort((a, b) => b.vendas - a.vendas)

      // Vendas por categoria
      const categorias = [...new Set(produtos.map(p => p.categoria).filter(Boolean))]
      const vendasPorCategoria = categorias.map(categoria => {
        const produtosCat = produtos.filter(p => p.categoria === categoria)
        const vendas = Math.floor(Math.random() * 30) + 5
        return {
          categoria,
          vendas,
          valor: vendas * 50 // Valor médio simulado
        }
      })

      setDashboardData({
        resumo: {
          vendas_mes: vendasMes.length,
          total_produtos: produtos.length,
          total_clientes: clientes.length,
          produtos_baixo_estoque: baixoEstoque.length,
          vendas_hoje: vendasHoje.length,
          receita_mes: receitaMes
        },
        vendas_por_dia: vendasPorDia,
        produtos_mais_vendidos: produtosMaisVendidos,
        vendas_por_categoria: vendasPorCategoria,
        vendas_recentes: vendas.slice(0, 5),
        estoque_critico: baixoEstoque.slice(0, 5)
      })

    } catch (err) {
      setError(err.message)
    } finally {
      setLoading(false)
    }
  }

  const COLORS = ['#0088FE', '#00C49F', '#FFBB28', '#FF8042', '#8884D8']

  if (loading) {
    return (
      <div className="space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          {[...Array(4)].map((_, i) => (
            <Card key={i} className="animate-pulse">
              <CardHeader className="pb-2">
                <div className="h-4 bg-gray-200 rounded w-3/4"></div>
              </CardHeader>
              <CardContent>
                <div className="h-8 bg-gray-200 rounded w-1/2"></div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    )
  }

  if (error) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="text-center">
          <AlertTriangle className="h-12 w-12 text-red-500 mx-auto mb-4" />
          <p className="text-red-500">Erro ao carregar dashboard: {error}</p>
        </div>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      {/* Métricas Principais */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Receita do Mês</CardTitle>
            <DollarSign className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              R$ {dashboardData.resumo.receita_mes.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
            </div>
            <p className="text-xs text-muted-foreground">
              <TrendingUp className="inline h-3 w-3 mr-1" />
              +12% em relação ao mês anterior
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Vendas do Mês</CardTitle>
            <ShoppingCart className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{dashboardData.resumo.vendas_mes}</div>
            <p className="text-xs text-muted-foreground">
              <TrendingUp className="inline h-3 w-3 mr-1" />
              +8% em relação ao mês anterior
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total de Produtos</CardTitle>
            <Package className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{dashboardData.resumo.total_produtos}</div>
            <p className="text-xs text-muted-foreground">
              {dashboardData.resumo.produtos_baixo_estoque > 0 && (
                <>
                  <AlertTriangle className="inline h-3 w-3 mr-1 text-red-500" />
                  {dashboardData.resumo.produtos_baixo_estoque} com baixo estoque
                </>
              )}
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total de Clientes</CardTitle>
            <Users className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{dashboardData.resumo.total_clientes}</div>
            <p className="text-xs text-muted-foreground">
              <TrendingUp className="inline h-3 w-3 mr-1" />
              +3 novos este mês
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Gráficos */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Vendas por Dia */}
        <Card>
          <CardHeader>
            <CardTitle>Vendas dos Últimos 7 Dias</CardTitle>
            <CardDescription>Número de vendas e receita por dia</CardDescription>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <AreaChart data={dashboardData.vendas_por_dia}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="data" />
                <YAxis />
                <Tooltip 
                  formatter={(value, name) => [
                    name === 'receita' ? `R$ ${value.toFixed(2)}` : value,
                    name === 'receita' ? 'Receita' : 'Vendas'
                  ]}
                />
                <Area type="monotone" dataKey="vendas" stackId="1" stroke="#8884d8" fill="#8884d8" />
              </AreaChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        {/* Vendas por Categoria */}
        <Card>
          <CardHeader>
            <CardTitle>Vendas por Categoria</CardTitle>
            <CardDescription>Distribuição de vendas por categoria de produto</CardDescription>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <PieChart>
                <Pie
                  data={dashboardData.vendas_por_categoria}
                  cx="50%"
                  cy="50%"
                  labelLine={false}
                  label={({ categoria, percent }) => `${categoria} ${(percent * 100).toFixed(0)}%`}
                  outerRadius={80}
                  fill="#8884d8"
                  dataKey="vendas"
                >
                  {dashboardData.vendas_por_categoria.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip />
              </PieChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>

      {/* Tabelas de Dados */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Produtos Mais Vendidos */}
        <Card>
          <CardHeader>
            <CardTitle>Produtos Mais Vendidos</CardTitle>
            <CardDescription>Top 5 produtos por quantidade vendida</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {dashboardData.produtos_mais_vendidos.map((produto, index) => (
                <div key={index} className="flex items-center justify-between">
                  <div className="flex items-center space-x-3">
                    <Badge variant="outline">{index + 1}</Badge>
                    <div>
                      <p className="font-medium">{produto.nome}</p>
                      <p className="text-sm text-muted-foreground">{produto.vendas} vendas</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="font-medium">R$ {produto.receita.toFixed(2)}</p>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Produtos com Estoque Crítico */}
        <Card>
          <CardHeader>
            <CardTitle>Estoque Crítico</CardTitle>
            <CardDescription>Produtos que precisam de reposição</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {dashboardData.estoque_critico.length > 0 ? (
                dashboardData.estoque_critico.map((produto, index) => (
                  <div key={index} className="flex items-center justify-between">
                    <div>
                      <p className="font-medium">{produto.nome}</p>
                      <p className="text-sm text-muted-foreground">{produto.categoria}</p>
                    </div>
                    <div className="text-right">
                      <Badge variant="destructive">
                        {produto.estoque_atual} / {produto.estoque_minimo}
                      </Badge>
                    </div>
                  </div>
                ))
              ) : (
                <div className="text-center py-4 text-muted-foreground">
                  <Target className="h-8 w-8 mx-auto mb-2" />
                  <p>Todos os produtos estão com estoque adequado!</p>
                </div>
              )}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Vendas Recentes */}
      <Card>
        <CardHeader>
          <CardTitle>Vendas Recentes</CardTitle>
          <CardDescription>Últimas transações realizadas</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {dashboardData.vendas_recentes.length > 0 ? (
              dashboardData.vendas_recentes.map((venda, index) => (
                <div key={index} className="flex items-center justify-between border-b pb-2">
                  <div className="flex items-center space-x-3">
                    <Activity className="h-4 w-4 text-muted-foreground" />
                    <div>
                      <p className="font-medium">Venda #{venda.id}</p>
                      <p className="text-sm text-muted-foreground">
                        {venda.cliente_nome || 'Cliente não informado'} • {new Date(venda.data_venda).toLocaleDateString('pt-BR')}
                      </p>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="font-medium">R$ {parseFloat(venda.total).toFixed(2)}</p>
                    <Badge variant={venda.status === 'concluida' ? 'default' : 'secondary'}>
                      {venda.status}
                    </Badge>
                  </div>
                </div>
              ))
            ) : (
              <div className="text-center py-4 text-muted-foreground">
                <Calendar className="h-8 w-8 mx-auto mb-2" />
                <p>Nenhuma venda registrada ainda</p>
              </div>
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

