import { useState } from 'react'
import { Button } from '@/components/ui/button.jsx'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card.jsx'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs.jsx'
import { Badge } from '@/components/ui/badge.jsx'
import { 
  ShoppingCart, 
  Package, 
  Users, 
  BarChart3, 
  DollarSign, 
  TrendingUp,
  AlertTriangle,
  Plus
} from 'lucide-react'
import EstoqueTab from './components/EstoqueTab.jsx'
import ClientesTab from './components/ClientesTab.jsx'
import VendasTab from './components/VendasTab.jsx'
import DashboardTab from './components/DashboardTab.jsx'
import './App.css'

function App() {
  const [activeTab, setActiveTab] = useState('dashboard')

  // Dados mockados para demonstração
  const dashboardStats = {
    vendas: { valor: 'R$ 12.450', variacao: '+12%' },
    estoque: { valor: '234 itens', variacao: '-5%' },
    clientes: { valor: '89 clientes', variacao: '+8%' },
    produtos: { valor: '156 produtos', variacao: '+3%' }
  }

  const vendasRecentes = [
    { id: 1, cliente: 'Maria Silva', valor: 'R$ 150,00', status: 'Pago' },
    { id: 2, cliente: 'João Santos', valor: 'R$ 89,50', status: 'Pendente' },
    { id: 3, cliente: 'Ana Costa', valor: 'R$ 245,00', status: 'Pago' }
  ]

  const produtosBaixoEstoque = [
    { nome: 'Camiseta Básica', estoque: 5, minimo: 10 },
    { nome: 'Calça Jeans', estoque: 2, minimo: 8 },
    { nome: 'Tênis Esportivo', estoque: 1, minimo: 5 }
  ]

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center">
              <h1 className="text-2xl font-bold text-gray-900">ERP Simples</h1>
              <Badge variant="secondary" className="ml-3">v1.0</Badge>
            </div>
            <div className="flex items-center space-x-4">
              <Button variant="outline" size="sm">
                Configurações
              </Button>
              <Button size="sm">
                Sair
              </Button>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="dashboard" className="flex items-center gap-2">
              <BarChart3 className="h-4 w-4" />
              Dashboard
            </TabsTrigger>
            <TabsTrigger value="vendas" className="flex items-center gap-2">
              <ShoppingCart className="h-4 w-4" />
              Vendas
            </TabsTrigger>
            <TabsTrigger value="estoque" className="flex items-center gap-2">
              <Package className="h-4 w-4" />
              Estoque
            </TabsTrigger>
            <TabsTrigger value="clientes" className="flex items-center gap-2">
              <Users className="h-4 w-4" />
              Clientes
            </TabsTrigger>
          </TabsList>

          {/* Dashboard Tab */}
          <TabsContent value="dashboard" className="space-y-6">
            <DashboardTab />
          </TabsContent>

          {/* Vendas Tab */}
          <TabsContent value="vendas" className="space-y-6">
            <VendasTab />
          </TabsContent>

          {/* Estoque Tab */}
          <TabsContent value="estoque" className="space-y-6">
            <EstoqueTab />
          </TabsContent>

          {/* Clientes Tab */}
          <TabsContent value="clientes" className="space-y-6">
            <ClientesTab />
          </TabsContent>
        </Tabs>
      </main>
    </div>
  )
}

export default App

